
'use strict';
layui.use(['jquery'],function(){
	window.jQuery = window.$ = layui.jquery;
   $(".layui-canvs").width($(window).width());
   $(".layui-canvs").height($(window).height());

});

$(document).ready(function() {
  //$('#particles').particleground({
  //  dotColor: '#fff',
  //  lineColor: '#fff'
  //});

   
    $("#Login").click(function(){
    	var username = $.trim($("#UserName").val());
    	var password = $.trim($("#Password").val());
    	var code=$.trim($("#code").val());
    	if(username == "" || username == null){
    		 $("#UserName").prop("placeholder", "用户名不能为空");
            $("#UserName").addClass("l_txtbx");

            $("#UserName").blur(function () {
                if (user.username == "") {
                    $("#UserName").removeClass("l_txtbx");
                }
            })
            return false;
    }else if(password == "" || password == null){
         $("#Password").prop("placeholder", "密码不能为空");
            $("#Password").addClass("l_txtbx");
            $("#Password").blur(function () {
                if (password == "") {
                    $("#Password").removeClass("l_txtbx");
                }
            })
            return false;
    }else if(code == "" || code == null){
        	 $("#code").prop("placeholder", "验证码不能为空");
            $("#code").addClass("l_txtbx");
            $("#code").blur(function () {
                if (code == "") {
                    $("#code").removeClass("l_txtbx");
                }
            })
            return false;
    }else{
    	 $.ajax({
            type:'POST',  //提交方法是POST
             url: '/User/Login', //请求的路径
             data: { username: username, password: password, code: code },
             dataType:'text', //后台返回的数据类型是html文本 
             success: function (result) {   //请求成功的回调方法
                // console.log(result);
                 //console.log(result== "\"failed\"");
                 if (result != "" && result == "\"success\"") {
                    
                     window.location.href = "/Home/Index";
                     //refresh();
                    } else if (result == "\"failed\"") {
                        alert("验证码输入错误！请重试。");
                        $("#code").val('');
                    } else if (result == "\"nologincode\"") {
                        alert("账号不存在！请重试。");
                        $("#UserName").val('');
                    } else if (result == "\"pwderror\"") {
                        alert("密码错误！请重试。");
                        $("#Password").val('');
                    } else if ("\"nodata\"" == result) {
                        alert("对不起，没有任何数据需要处理！请重试。");
                    }
                },
             error:function(ex){  //请求失败的回调方法
                alert("登录失败！请重试。");
            }
		});
	}
    });	

    //refresh();

    function refresh() {
        setTimeout(refresh, 1200000);
        $.ajax({
            type: "post",
            url: "/User/RefreshData",
            async: true,
            success: function () {
                console.log("成功")
            }

        })
    }
});