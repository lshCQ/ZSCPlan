﻿using Model;
using StaffBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StaffSystemWeb.Controllers
{
    public class BaseController : Controller
    {
        // GET: Base
        public ActionResult Index(int ID)
        {
            List<Role_Menu> rolemenu = new Role_MenuBLL().List(o => o.RoleID == ID);
            List<Menu> menu = new List<Menu>();
            foreach (var temp in rolemenu)
            {
                Menu Menus = new Menu();
                Menus = new MenuBLL().Get(o => o.ID == temp.MenuID);
                menu.Add(Menus);
            }
            ViewBag.menu = menu;
            ViewData["Role"] = new RoleBLL().Get(o => o.ID == ID);
            return View(rolemenu);
        }
    }
}