﻿using Model;
using StaffBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace StaffSystemWeb.Controllers
{
    public class UsersController : Controller
    {
        // GET: Users
        [HttpGet]
        public ViewResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Users model)
        {
            var password = MD5Encrypt32(model.PassWord);
            var account = model.Account;
            var loginuser = new UserBLL().Get(m => m.Account == account && m.PassWord == password);
            if (loginuser != null)//当用户名和密码正确时
            {
                Role role = new Role();
                role = new RoleBLL().Get(o => o.ID == loginuser.RoleID);
                int ID = role.ID;
                //页面跳转到主页面
                return RedirectToAction("Index", "Base", new { ID = ID });
            }
            else
            {
                //如果登录不成功，则向用户提示错误信息
                ViewBag.ErrorMsg = "用户名或密码错误。";
                return View(model);
            }
            return View();
        }
        /// <summary>
        /// 32位MD5加密
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string MD5Encrypt32(string password)
        {
            string pwd = "";
            MD5 md5 = MD5.Create(); //实例化一个md5对像
            // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(password));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
                pwd = pwd + s[i].ToString("X2");
            }
            return pwd;
        }
    }
}