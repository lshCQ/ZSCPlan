﻿using Model;
using StaffBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Common;

namespace StaffSystemWeb.Controllers
{
    public class StaffManagerController : Controller
    {
        // GET: StaffManager
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult GetAll(int page, int limit, string StaffName)
        {
            if(StaffName==null)
            {
                StaffName = "";
            }
            List<Staffs> list = new StaffsBLL().GetPageData(page, limit, o => o.StaffName.Contains(StaffName),o=> o.Age.ToString());
            int msg = new StaffsBLL().Count(o => o.StaffName.Contains(StaffName));
            ResultHelper result=new ResultHelper();
            result.status = 0;
            result.total = msg;
            result.message = "返回数据成功";
            result.data = list;
            return Json(result);
        }
        [HttpPost]
        public JsonResult Add(string StaffName,int Age,string PhoneNumber,string Address,string Position)
        {
            Staffs staff=new Staffs();
            staff.StaffName = StaffName;
            staff.Age = Age;
            staff.PhoneNumber = PhoneNumber;
            staff.Address = Address;
            staff.Position = Position;
            int msg = new StaffsBLL().Add(staff);
            return Json(msg);
        }
        [HttpPost]
        public JsonResult Delete(int id)
        {
            Staffs staff = new Staffs();
            staff = new StaffsBLL().Get(o=>o.ID==id);
            int msg = new StaffsBLL().Delete(staff);
            return Json(msg);
        }
        public ActionResult Edit(int id)
        {
            Staffs staff = new Staffs();
            staff = new StaffsBLL().Get(o => o.ID == id);
            return View(staff);
        }
        [HttpPost]
        public JsonResult Update(int id, string StaffName, int Age, string PhoneNumber, string Address, string Position)
        {
            Staffs staff = new Staffs();
            staff.ID = id;
            staff.StaffName = StaffName;
            staff.Age = Age;
            staff.PhoneNumber = PhoneNumber;
            staff.Address = Address;
            staff.Position = Position;
            int msg = new StaffsBLL().Update(staff);
            return Json(msg);
        }
    }
}