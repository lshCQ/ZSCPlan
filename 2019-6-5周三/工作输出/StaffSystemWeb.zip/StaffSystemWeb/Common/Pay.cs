﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ThoughtWorks.QRCode.Codec;

namespace Common
{
    public class Pay
    {
        //sParaTemp参数是一个键/值对集合
        //支付宝支付
        public static string GetSignStr(SortedDictionary<string, string> sParaTemp)
        {
            List<string> NameList = sParaTemp.Keys.ToList();
            NameList.Sort();
            string Str = "";
            try
            {
                foreach (var item in NameList)
                {
                    if (string.IsNullOrEmpty(sParaTemp[item]))
                        continue;
                    if (Str != "")
                        Str += "&";
                    Str += item + "=" + sParaTemp[item];
                }
            }
            catch (Exception)
            {
            }
            return Str;
        }
        //微信支付
        public static string GetSignStr(object param)
        {
            List<PropertyInfo> smList = param.GetType().GetProperties().ToList();
            List<string> NameList = new List<string>();
            foreach (var item in smList)
            {
                NameList.Add(item.Name);
            }
            NameList.Sort();
            string Str = "";
            try
            {
                foreach (var item in NameList)
                {
                    PropertyInfo pInfo = smList.FirstOrDefault(p => p.Name == item);
                    if (pInfo == null)
                        continue;
                    object value = pInfo.GetValue(param, null);
                    if (value == null)
                        continue;
                    if (Str != "")
                        Str += "&";
                    Str += item + "=" + value;
                }
            }
            catch (Exception)
            {
            }
            return Str;
        }        
    }
}
