﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Common
{
    public class ResultHelper
    {
        public int status { get; set; }
        public string message { get; set; }
        public int total { get; set; }
        public List<Staffs> data { get; set; }

    }
}
