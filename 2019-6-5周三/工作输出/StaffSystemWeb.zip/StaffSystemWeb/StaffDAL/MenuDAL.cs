﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffDAL
{
    public class MenuDAL
    {
        /// <summary>
        /// 数据库访问上下文对象
        /// </summary>
        protected StaffEntities Context = new StaffEntities();
        /// <summary>
        /// 查询所有角色
        /// </summary>
        public List<Menu> GetAll()
        {
            List<Menu> list = Context.Menu.Select(o => o).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Menu> List(Expression<Func<Menu, bool>> whereLamdba)
        {
            List<Menu> list = Context.Menu.Where(whereLamdba).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Menu Get(Expression<Func<Menu, bool>> exprssion)
        {
            Menu menu = Context.Menu.Single(exprssion);
            Context.SaveChanges();
            return menu;
        }

        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Menu menu)
        {
            Context.Menu.Remove(menu);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Menu> list)
        {
            Context.Menu.RemoveRange(list);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Menu menu)
        {
            Context.Menu.Add(menu);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Menu menu)
        {
            Context.Menu.Attach(menu);
            Context.Entry<Menu>(menu).State = EntityState.Modified;
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            Context.Menu.Count();
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Menu, bool>> experssion)
        {
            Context.Menu.Count(experssion);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Menu> GetPageData(int pageIndex, int pageSize, Expression<Func<Menu, bool>> wherelamdba, Expression<Func<Menu, object>> orderbylamdba)
        {
            return Context.Menu.Where(wherelamdba).OrderBy(orderbylamdba).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }

    }
}
