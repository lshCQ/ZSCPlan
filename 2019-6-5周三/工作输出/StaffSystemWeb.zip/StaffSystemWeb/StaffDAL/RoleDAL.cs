﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffDAL
{
    public class RoleDAL
    {
        /// <summary>
        /// 数据库访问上下文对象
        /// </summary>
        protected StaffEntities Context = new StaffEntities();
        /// <summary>
        /// 查询所有角色
        /// </summary>
        public List<Role> GetAll()
        {
            List<Role> list = Context.Role.Select(o => o).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Role> List(Expression<Func<Role, bool>> whereLamdba)
        {
            List<Role> list = Context.Role.Where(whereLamdba).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Role Get(Expression<Func<Role, bool>> exprssion)
        {
            Role role = Context.Role.Single(exprssion);
            Context.SaveChanges();
            return role;
        }

        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Role role)
        {
            Context.Role.Remove(role);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Role> list)
        {
            Context.Role.RemoveRange(list);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Role role)
        {
            Context.Role.Add(role);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Role role)
        {
            Context.Role.Attach(role);
            Context.Entry<Role>(role).State = EntityState.Modified;
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            Context.Role.Count();
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Role, bool>> experssion)
        {
            Context.Role.Count(experssion);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Role> GetPageData(int pageIndex, int pageSize, Expression<Func<Role, bool>> wherelamdba, Expression<Func<Role, object>> orderbylamdba)
        {
            return Context.Role.Where(wherelamdba).OrderBy(orderbylamdba).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }

    }
}
