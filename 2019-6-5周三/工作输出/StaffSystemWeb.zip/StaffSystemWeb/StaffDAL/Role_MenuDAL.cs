﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffDAL
{
    public class Role_MenuDAL
    {
        /// <summary>
        /// 数据库访问上下文对象
        /// </summary>
        protected StaffEntities Context = new StaffEntities();
        /// <summary>
        /// 查询所有员工
        /// </summary>
        public List<Role_Menu> GetAll()
        {
            List<Role_Menu> list = Context.Role_Menu.Select(o => o).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Role_Menu> List(Expression<Func<Role_Menu, bool>> whereLamdba)
        {
            List<Role_Menu> list = Context.Role_Menu.Where(whereLamdba).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Role_Menu Get(Expression<Func<Role_Menu, bool>> exprssion)
        {
            Role_Menu role_menu = Context.Role_Menu.Single(exprssion);
            Context.SaveChanges();
            return role_menu;
        }
        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Role_Menu role_menu)
        {
            Context.Role_Menu.Remove(role_menu);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Role_Menu> list)
        {
            Context.Role_Menu.RemoveRange(list);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Role_Menu role_menu)
        {
            Context.Role_Menu.Add(role_menu);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Role_Menu role_menu)
        {
            Context.Role_Menu.Attach(role_menu);
            Context.Entry<Role_Menu>(role_menu).State = EntityState.Modified;
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            Context.Role_Menu.Count();
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Role_Menu, bool>> experssion)
        {
            Context.Role_Menu.Count(experssion);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Role_Menu> GetPageData(int pageIndex, int pageSize, Expression<Func<Role_Menu, bool>> wherelamdba, Expression<Func<Role_Menu, object>> orderbylamdba)
        {
            return Context.Role_Menu.Where(wherelamdba).OrderBy(orderbylamdba).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }
    }
}
