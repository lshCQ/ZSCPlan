﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffDAL
{
    public class StaffsDAL
    {
        /// <summary>
        /// 数据库访问上下文对象
        /// </summary>
        protected StaffEntities Context = new StaffEntities();
        /// <summary>
        /// 查询所有员工
        /// </summary>
        public List<Staffs> GetAll()
        {
            List<Staffs> list = Context.Staffs.Select(o => o).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Staffs> List(Expression<Func<Staffs, bool>> whereLamdba)
        {
            List<Staffs> list = Context.Staffs.Where(whereLamdba).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Staffs Get(Expression<Func<Staffs, bool>> exprssion)
        {
            Staffs staff = Context.Staffs.Single(exprssion);
            Context.SaveChanges();
            return staff;
        }
        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Staffs staff)
        {
            Context.Entry<Staffs>(staff).State = EntityState.Deleted;
            Context.Staffs.Remove(staff);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Staffs> list)
        {
            Context.Staffs.RemoveRange(list);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Staffs staff)
        {
            Context.Staffs.Add(staff);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Staffs staff)
        {
            Context.Staffs.Attach(staff);
            Context.Entry<Staffs>(staff).State = EntityState.Modified;
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            int msg=Context.Staffs.Count();
            return msg;
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Staffs, bool>> experssion)
        {
            int msg=Context.Staffs.Count(experssion);
            return msg;
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Staffs> GetPageData(int pageIndex, int pageSize, Expression<Func<Staffs, bool>> wherelamdba, Expression<Func<Staffs, string>> orderlamdba)
        {
            return Context.Staffs.Where(wherelamdba).OrderBy(orderlamdba).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }
    }
}
