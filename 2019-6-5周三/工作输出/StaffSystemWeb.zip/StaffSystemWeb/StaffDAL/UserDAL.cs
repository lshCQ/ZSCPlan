﻿

using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffDAL
{
    public class UserDAL
    {
        /// <summary>
        /// 数据库访问上下文对象
        /// </summary>
        protected StaffEntities Context = new StaffEntities();
        /// <summary>
        /// 查询所有用户
        /// </summary>
        public List<Users> GetAll()
        {
            List<Users> list= Context.Users.Select(o => o).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Users> List(Expression<Func<Users, bool>> whereLamdba)
        {
            List<Users> list = Context.Users.Where(whereLamdba).ToList();
            Context.SaveChanges();
            return list;
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Users Get(Expression<Func<Users, bool>> exprssion)
        {
            Users user = Context.Users.Single(exprssion);
            Context.SaveChanges();
            return user;
        }
        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Users user)
        {
            Context.Users.Remove(user);
            int msg=Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Users> list)
        {
            Context.Users.RemoveRange(list);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Users user)
        {
            Context.Users.Add(user);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Users user)
        {
            Context.Users.Attach(user);
            Context.Entry<Users>(user).State = EntityState.Modified;
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            Context.Users.Count();
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Users,bool>> experssion)
        {
            Context.Users.Count(experssion);
            int msg = Context.SaveChanges();
            return msg;
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Users> GetPageData(int pageIndex, int pageSize, Expression<Func<Users, bool>> wherelamdba, Expression<Func<Users, object>> orderbylamdba)
        {
            return Context.Users.Where(wherelamdba).OrderBy(orderbylamdba).Skip((pageIndex-1)*pageSize).Take(pageSize).ToList();
        }
    }
}
