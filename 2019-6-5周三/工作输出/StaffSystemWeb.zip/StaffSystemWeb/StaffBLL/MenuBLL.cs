﻿using Model;
using StaffDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffBLL
{
    public class MenuBLL
    {
        MenuDAL dal = new MenuDAL();
        /// <summary>
        /// 查询所有用户
        /// </summary>
        public List<Menu> GetAll()
        {
            return dal.GetAll();
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Menu> List(Expression<Func<Menu, bool>> whereLamdba)
        {
            return dal.List(whereLamdba);
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Menu Get(Expression<Func<Menu, bool>> exprssion)
        {
            return dal.Get(exprssion);
        }
        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Menu menu)
        {
            return dal.Delete(menu);
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Menu> list)
        {
            return dal.DeleteCount(list);
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Menu menu)
        {
            return dal.Add(menu);
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Menu menu)
        {
            return dal.Update(menu);
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            return dal.Count();
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Menu, bool>> experssion)
        {
            return dal.Count(experssion);
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Menu> GetPageData(int pageIndex, int pageSize, Expression<Func<Menu, bool>> wherelamdba, Expression<Func<Menu, object>> orderbylamdba)
        {
            return dal.GetPageData(pageIndex, pageSize, wherelamdba, orderbylamdba);
        }
    }
}
