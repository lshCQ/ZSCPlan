﻿using Model;
using StaffDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StaffBLL
{
    public class UserBLL
    {
        UserDAL dal = new UserDAL();
        /// <summary>
        /// 查询所有用户
        /// </summary>
        public List<Users> GetAll()
        {
            return dal.GetAll();
        }
        /// <summary>
        /// 根据条件查询
        /// </summary>
        public List<Users> List(Expression<Func<Users, bool>> whereLamdba)
        {
            return dal.List(whereLamdba);
        }
        /// <summary>
        /// 查询具体的一个实体
        /// </summary>
        public Users Get(Expression<Func<Users, bool>> exprssion)
        {
            return dal.Get(exprssion);
        }
        /// <summary>
        /// 先查询出实体再删除
        /// </summary>
        public int Delete(Users user)
        {
            return dal.Delete(user);
        }
        /// <summary>
        /// 批量删除实体
        /// </summary>
        public int DeleteCount(List<Users> list)
        {
            return dal.DeleteCount(list);
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        public int Add(Users user)
        {
            return dal.Add(user);
        }
        /// <summary>
        /// 先查询出实体,再修改
        /// </summary>
        public int Update(Users user)
        {
            return dal.Update(user);
        }
        /// <summary>
        /// 查询实体总数
        /// </summary>
        public int Count()
        {
            return dal.Count();
        }
        /// <summary>
        /// 根据条件查询实体总数
        /// </summary>
        public int Count(Expression<Func<Users, bool>> experssion)
        {
            return dal.Count(experssion);
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        public List<Users> GetPageData(int pageIndex, int pageSize, Expression<Func<Users, bool>> wherelamdba, Expression<Func<Users, object>> orderbylamdba)
        {
            return dal.GetPageData(pageIndex, pageSize, wherelamdba, orderbylamdba);
        }
    }
}
